def ISLP(y):
    if(y % 4 == 0):
      print("true");
    else:
      print("false");
year=int(input("Enter the year:"));
print(ISLP(year));
